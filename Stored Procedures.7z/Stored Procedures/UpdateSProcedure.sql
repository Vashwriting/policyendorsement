﻿CREATE PROCEDURE [vidhu].[spPolicy]
   @PolicyNumber int, 
   @CustomerNumber int,
   @Productid int,
   @Planname varchar(45),
   @Policyterm int,
   @Payterm int,
   @TotalPayout int,
   @SumAssured int ,
   @BasePremium int,
   @TotalPremium int
AS
	update [vidhu].[Policy] set Planname=@Planname, Policyterm=@Policyterm, Payterm=@Payterm, TotalPayout=@TotalPayout, SumAssured=@SumAssured, BasePremium=@BasePremium, TotalPremium=@TotalPremium where Customerno=@CustomerNumber and Policyno=@PolicyNumber;
RETURN 0
