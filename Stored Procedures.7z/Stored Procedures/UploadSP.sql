﻿CREATE PROCEDURE [vidhu].[UploadSP]
   @Policyno int,
   @Idcard varchar(15),
   @Photo image
AS
	begin
	insert into [vidhu].[Document] values (@Policyno,@Idcard,@Photo)
end
RETURN 0