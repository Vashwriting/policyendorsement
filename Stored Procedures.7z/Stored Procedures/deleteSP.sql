﻿CREATE PROCEDURE [vidhu].[deleteSP]
   @PolicyNumber int,
   @CustomerNumber int
AS
	delete from [vidhu].[Policy] where Customerno=@CustomerNumber and Policyno=@PolicyNumber
	
RETURN 0