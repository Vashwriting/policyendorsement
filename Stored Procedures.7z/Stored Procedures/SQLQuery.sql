
----Table for customer to register----

create table [vidhu].[customer]
(
	 Name varchar(30) not null,
	 Address varchar(50) not null,
	 Telephone varchar(10) not null,
	 Gender varchar(7) not null,
	 DOB Datetime not null,
	 Hobbies varchar(30) not null,
	 Smoker varchar(10) not null,
	 Loginid varchar(20) not null,
     Password varchar(15) primary key not null, 
)

select * from [vidhu].[customer]

------Table for policy-----

create table [vidhu].[Policy]
(
   Policyno int not null, 
   Customerno int not null,
   Productid int not null,
   Planname varchar(45) not null,
   Policyterm int not null,
   Payterm int not null,
   TotalPayout int not null,
   SumAssured int not null,
   BasePremium int not null,
   TotalPremium int not null,
)

select * from [vidhu].[Policy]

----Table for Insurance Products----

create table [vidhu].[InsuranceProducts]
(
   Policyno int not null,
   ProductLine varchar(15) not null,
   ProductName varchar(25) not null,
   InsuredName varchar(25) not null,
   InsuredAge int not null,
   DOB datetime not null,
   Gender varchar(10) not null,
   Nominee varchar(20) not null,
   Relation varchar(20) not null,
   Smoker varchar(10) not null,
   Address varchar(50) not null,
   Telephone varchar(10) not null,
   PremiumPaymentfrequency varchar(20) not null
)

select * from [vidhu].[InsuranceProducts]

insert into [vidhu].[InsuranceProducts] values (1001,'NonLife','CancerPolicy','Health Insurance',30,10/09/1988,'Male','vineeth','brother','NonSmoker','hyderabad',8499828338,'Quarterly')
insert into [vidhu].[InsuranceProducts] values (1002,'Life','TripPolicy','Travel Insurance',23,10/09/1997,'FeMale','Chandhana','Mother','NonSmoker','hyderabad',8499828338,'Monthly')
insert into [vidhu].[InsuranceProducts] values (1003,'Life','TataPolicy','Car Insurance',25,10/09/1995,'Male','Saswin','brother','NonSmoker','Bangalore',9989640526,'Yearly')
insert into [vidhu].[InsuranceProducts] values (1004,'NonLife','MentalHealthPolicy','Health Insurance',40,10/09/1978,'Male','Ramana','Father','NonSmoker','Chennai',8499828338,'Quarterly')
insert into [vidhu].[InsuranceProducts] values (1005,'Life','CompanyPolicy','Business Insurance',30,10/09/1978,'Male','Rithu','Sister','NonSmoker','pune',8499828338,'HalfYearly')
insert into [vidhu].[InsuranceProducts] values (1006,'Life','BMWPolicy','Car Insurance',30,10/09/1978,'Male','vineeth','Husband','Smoker','hyderabad',9876543210,'Quarterly')
insert into [vidhu].[InsuranceProducts] values (1007,'Life','TrekkingPolicy','Travel Insurance',30,10/09/1978,'Male','Sandeep','brother','Smoker','Bangalore',9505668125,'HalfYearly')
insert into [vidhu].[InsuranceProducts] values (1008,'Life','BrainTumorPolicy','Health Insurance',40,10/09/1978,'FeMale','Usha','Mother','NonSmoker','Chennai',8976543076,'Monthly')
insert into [vidhu].[InsuranceProducts] values (1009,'Life','NewHousePolicy','House Insurance',23,10/09/1997,'Male','PavanSai','brother','Smoker','hyderabad',9856743215,'Yearly')


-------table for documentupload----

create table [vidhu].[Document]
(
   Policyno int not null,
   Idcard varchar(15) not null,
   Photo image not null
)

select * from [vidhu].[Document]

