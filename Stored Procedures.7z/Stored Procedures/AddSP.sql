﻿CREATE PROCEDURE [vidhu].[AddSP]
   @PolicyNumber int, 
   @CustomerNumber int,
   @Productid int,
   @Planname varchar(45),
   @Policyterm int,
   @Payterm int,
   @TotalPayout int,
   @SumAssured int ,
   @BasePremium int,
   @TotalPremium int
AS
begin
	insert into [vidhu].[Policy] values (@PolicyNumber,@CustomerNumber,@Productid,@Planname,@Policyterm,@Payterm,@TotalPayout,@SumAssured,@BasePremium,@TotalPremium)
end
	
RETURN 0
