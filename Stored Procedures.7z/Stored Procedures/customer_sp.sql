﻿CREATE PROCEDURE [vidhu].[customer_sp]
	@Name varchar(30),
	@Address varchar(50),
	@telephone varchar(10),
	@gender varchar(7),
	@DOB Datetime,
	@Hobbies varchar(30),
	@Smoker varchar(10),
	@Loginid varchar(20),
	@Password varchar(15)
	
AS
begin
	insert into [vidhu].[customer] values (@Name,@Address,@telephone,@gender,@DOB,@Hobbies,@Smoker,@Loginid,@Password)
end