﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPE_Entity;
using IPE_Exception;

namespace IPE_DAL
{
    public class Customer_DAL
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool customerDAL(Customer c)
        {
            bool isPersonadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vidhu].[customer_sp]";
                Command.Parameters.AddWithValue("@Name", c.Name);
                Command.Parameters.AddWithValue("@Address", c.Address);
                Command.Parameters.AddWithValue("@telephone", c.telephone);
                Command.Parameters.AddWithValue("@gender", c.gender);
                Command.Parameters.AddWithValue("@DOB", c.DOB);
                Command.Parameters.AddWithValue("@Hobbies", c.Hobbies);
                Command.Parameters.AddWithValue("@Smoker", c.Smoker);
                Command.Parameters.AddWithValue("@Loginid", c.Loginid);
                Command.Parameters.AddWithValue("@Password", c.Password);
               
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isPersonadded = true;
            }
            catch (PolicyException)
            {
                throw;
            }
            return isPersonadded;
        }
    }
}
