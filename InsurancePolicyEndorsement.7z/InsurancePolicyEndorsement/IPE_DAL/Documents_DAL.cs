﻿using IPE_Entity;
using IPE_Exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_DAL
{
    public class Documents_DAL
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool UploadDAL(Documents d)
        {
            bool iscardadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vidhu].[UploadSP]";
                Command.Parameters.AddWithValue("@Policyno", d.PolicyNumber);
                Command.Parameters.AddWithValue("@Idcard", d.SelecttheCard);
                Command.Parameters.AddWithValue("@Photo", d.Photo);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    iscardadded = true;
            }
            catch (PolicyException)
            {
                throw;
            }
            return iscardadded;
        }
    }
}
