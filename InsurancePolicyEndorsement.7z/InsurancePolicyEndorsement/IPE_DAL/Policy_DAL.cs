﻿using IPE_Entity;
using IPE_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_DAL
{
    public class Policy_DAL
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand Command = new SqlCommand();


        public Policy SearchPolicyDAL(Policy p)
        {
            Policy SearchedPolicy = new Policy();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                Command.Connection = connection;
                string query = "spSearchPolicy";
                Command.Parameters.AddWithValue("@CustomerNumber", p);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedPolicy.PolicyNumber = int.Parse(Reader[0].ToString());
                        SearchedPolicy.CustomerNumber = int.Parse(Reader[1].ToString());
                        SearchedPolicy.Productid = int.Parse(Reader[2].ToString());
                        SearchedPolicy.Planname = Reader[3].ToString();
                        SearchedPolicy.Policyterm = int.Parse(Reader[4].ToString());
                        SearchedPolicy.Payterm = int.Parse(Reader[5].ToString());
                        SearchedPolicy.TotalPayout = int.Parse(Reader[6].ToString());
                        SearchedPolicy.SumAssured = int.Parse(Reader[7].ToString());
                        SearchedPolicy.BasePremium = int.Parse(Reader[8].ToString());
                        SearchedPolicy.TotalPremium = int.Parse(Reader[9].ToString());
                    }
                }
            }
            catch (PolicyException)
            {
                throw;
            }
            return SearchedPolicy;
        }

        public bool UpdatePolicyDAL(Policy p)
        {
            bool UpdatePolicy = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                Command = new SqlCommand();
                Command.CommandText = "[vidhu].[spPolicy]";
                Command.Connection = connection;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                Command.Parameters.AddWithValue("@PolicyNumber", p.PolicyNumber);
                Command.Parameters.AddWithValue("@CustomerNumber", p.CustomerNumber);
                Command.Parameters.AddWithValue("@Productid", p.Productid);
                Command.Parameters.AddWithValue("@Planname", p.Planname);
                Command.Parameters.AddWithValue("@Policyterm", p.Policyterm);
                Command.Parameters.AddWithValue("@Payterm", p.Payterm);
                Command.Parameters.AddWithValue("@TotalPayout", p.TotalPayout);
                Command.Parameters.AddWithValue("@SumAssured", p.SumAssured);
                Command.Parameters.AddWithValue("@BasePremium", p.BasePremium);
                Command.Parameters.AddWithValue("@TotalPremium", p.TotalPremium);

                
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded >= 1)
                    UpdatePolicy = true;
            }
            catch (PolicyException e)
            {
                throw e;
            }
            return UpdatePolicy;
        }

        public bool DeletePolicyDAL(int cno,int pno)
        {

            bool ispolicydeleted = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                //SqlCommand com = new SqlCommand();
                Command.Connection = connection;
                string query = "[vidhu].[deleteSP]";
               
                Command.CommandType = CommandType.StoredProcedure;
                Command.CommandText = query;
                Command.Parameters.AddWithValue("@CustomerNumber", cno);
                Command.Parameters.AddWithValue("@PolicyNumber", pno);

                int NumberOfRowsdeleted = Command.ExecuteNonQuery();

                if (NumberOfRowsdeleted == 1)
                    ispolicydeleted = true;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (PolicyException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return ispolicydeleted;

        }

        public bool AddPolicyDAL(Policy a)
        {
            bool isPersonadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[vidhu].[AddSP]";

                Command.Parameters.AddWithValue("@PolicyNumber", a.PolicyNumber);
                Command.Parameters.AddWithValue("@CustomerNumber", a.CustomerNumber);
                Command.Parameters.AddWithValue("@Productid", a.Productid);
                Command.Parameters.AddWithValue("@Planname", a.Planname);
                Command.Parameters.AddWithValue("@Policyterm", a.Policyterm);
                Command.Parameters.AddWithValue("@Payterm", a.Payterm);
                Command.Parameters.AddWithValue("@TotalPayout", a.TotalPayout);
                Command.Parameters.AddWithValue("@SumAssured", a.SumAssured);
                Command.Parameters.AddWithValue("@BasePremium", a.BasePremium);
                Command.Parameters.AddWithValue("@TotalPremium", a.TotalPremium);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isPersonadded = true;
            }
            catch (PolicyException)
            {
                throw;
            }
            return isPersonadded;
        }
    }
}
