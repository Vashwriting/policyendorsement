﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IPE_Entity;
using IPE_Exception;
using IPE_BLL;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for Customers.xaml
    /// </summary>
    public partial class Customers : Page
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void butregister_Click(object sender, RoutedEventArgs e)
        {
            Customer c = new Customer();
            c.Name = txtName.Text;
            c.Address = txtAddress.Text;
            c.telephone = txtphone.Text;
            c.DOB = DateTime.Parse(txtDOB.Text);
            c.Hobbies = txtHobbies.Text;
            c.gender = cmbgender.Text;
            c.Smoker = cmbsmkr.Text;
            c.Loginid = int.Parse(txtloginid.Text);
            c.Password = txtpwd.Password;
           
            AddPerson(c);
        }

        private static void AddPerson(Customer c)
        {
            try
            {
                bool personadded = Customer_BLL.customerBLL(c);
                if (personadded)
                {
                    MessageBox.Show("Registered Successfully");

                }
                else
                    MessageBox.Show("Details not registered");
            }
            catch (PolicyException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void butlogin_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from register page to login page
            this.NavigationService.Navigate(new Uri("LogIn.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
