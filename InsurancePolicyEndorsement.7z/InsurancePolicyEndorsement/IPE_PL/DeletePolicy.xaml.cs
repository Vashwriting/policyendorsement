﻿using IPE_BLL;
using IPE_Exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for DeletePolicy.xaml
    /// </summary>
    public partial class DeletePolicy : Page
    {
        public DeletePolicy()
        {
            InitializeComponent();
        }
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int cno = int.Parse(txtcno.Text);
            int pno = int.Parse(txtpno.Text);
            DeletePolicyPL(cno,pno);
        }

        private void DeletePolicyPL(int cno,int pno)
        {
            try
            {
                bool policyDeleted = Policy_BLL.DeletePolicyBLL(cno,pno);
                if (policyDeleted)
                    MessageBox.Show("Policy Deleted");
                else
                    MessageBox.Show("Policy is not Deleted");
            }
            catch (PolicyException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }

        private void nplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from DeletePolicy page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
