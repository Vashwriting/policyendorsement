﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IPE_Entity;
using IPE_Exception;
using IPE_BLL;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for AddPolicy.xaml
    /// </summary>
    public partial class AddPolicy : Page
    {
        public AddPolicy()
        {
            InitializeComponent();
        }

        

        private void hplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from AddPolicy page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }

        private void butAdd_Click(object sender, RoutedEventArgs e)
        {
            Policy p = new Policy();
            p.CustomerNumber = Int32.Parse(txtcno.Text);
            p.PolicyNumber = Int32.Parse(txtpno.Text);
            p.Productid = Int32.Parse(txtprdid.Text);
            p.Planname = txtpname.Text;
            p.Policyterm = Int32.Parse(txtpterm.Text);
            p.Payterm = Int32.Parse(txtpayterm.Text);
            p.TotalPayout = Int32.Parse(txttpout.Text);
            p.SumAssured = Int32.Parse(txtsad.Text);
            p.BasePremium = Int32.Parse(txtbp.Text);
            p.TotalPremium = Int32.Parse(txttp.Text);

            AddPolicyDetails(p);
        }

        private static void AddPolicyDetails(Policy p)
        {
            try
            {
                bool personadded = Policy_BLL.AddPolicyBLL(p);
                if (personadded)
                {
                    MessageBox.Show("Added Successfully");

                }
                else
                    MessageBox.Show("Policy not Added");
            }
            catch (PolicyException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
