﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : Page
    {
        public ViewPolicy()
        {
            InitializeComponent();
        }

        public void loadgridHI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='Health Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hplhealth_Click(object sender, RoutedEventArgs e)
        {
            loadgridHI() ;
        }

        public void loadgridLI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='Life Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hpllife_Click(object sender, RoutedEventArgs e)
        {
            loadgridLI();
        }

        public void loadgridTI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='Travel Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hpltravel_Click(object sender, RoutedEventArgs e)
        {
            loadgridTI();
        }

        public void loadgridCI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='Car Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hplcar_Click(object sender, RoutedEventArgs e)
        {
            loadgridCI();
        }

        public void loadgridBI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='Business Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hplbusiness_Click(object sender, RoutedEventArgs e)
        {
            loadgridBI();
        }

        public void loadgridHsI()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query = "select * from [vidhu].[InsuranceProducts] where InsuredName='House Insurance'";
                com.CommandText = query;
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void hplhouse_Click(object sender, RoutedEventArgs e)
        {
            loadgridHsI();
        }

        private void nplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from ViewPolicy page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }
    }

}
