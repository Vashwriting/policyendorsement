﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            string constring = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            SqlConnection connection = new SqlConnection(constring);
            try
            {
                connection.Open();
                string query = "select Loginid,Password from [vidhu].[customer] where Loginid='" + txtid.Text + "' and Password='" + txtpwd.Password.ToString() + "' ";
                SqlCommand cmd = new SqlCommand(query, connection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Login Successful");
                    this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
                }
                else
                {
                    MessageBox.Show("Invalid LoginId or Password");
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnsignin_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Customer page to Login page
            this.NavigationService.Navigate(new Uri("Customers.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
