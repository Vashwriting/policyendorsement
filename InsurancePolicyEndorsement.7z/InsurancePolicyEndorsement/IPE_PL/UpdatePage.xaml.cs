﻿using IPE_BLL;
using IPE_Entity;
using IPE_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for UpdatePage.xaml
    /// </summary>
    public partial class UpdatePage : Page
    {
        public UpdatePage()
        {
            InitializeComponent();
        }

        private void butupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Policy p = new Policy();

                p.CustomerNumber = Int32.Parse(txtcno.Text);
                p.PolicyNumber = Int32.Parse(txtpno.Text);
                p.Productid = Int32.Parse(txtprdid.Text);
                p.Planname = txtpname.Text;
                p.Policyterm = Int32.Parse(txtpterm.Text);
                p.Payterm = Int32.Parse(txtpayterm.Text);
                p.TotalPayout = Int32.Parse(txttpout.Text);
                p.SumAssured = Int32.Parse(txtsad.Text);
                p.BasePremium = Int32.Parse(txtbp.Text);
                p.TotalPremium = Int32.Parse(txttp.Text);

                bool updatepolicy = Policy_BLL.UpdatePolicyBLL(p);

                if (updatepolicy)
                {
                    MessageBox.Show("policy updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (PolicyException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void nplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Update page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
