﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : Page
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        private void rbtcno_Click(object sender, RoutedEventArgs e)
        {
            lblpno.Visibility = Visibility.Hidden;
            txtpno.Visibility = Visibility.Hidden;
            lblcno.Visibility = Visibility.Visible;
            txtcno.Visibility = Visibility.Visible;
        }

        private void rbtpno_Click(object sender, RoutedEventArgs e)
        {
            lblcno.Visibility = Visibility.Hidden;
            txtcno.Visibility = Visibility.Hidden;
            lblpno.Visibility = Visibility.Visible;
            txtpno.Visibility = Visibility.Visible;
        }

        public void loadgrid()
        {
            SqlConnection con = new SqlConnection();
            int cno;
            int pno;
           
            try
            {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                string query1;
                if (txtcno.Text != "")
                {
                    cno = int.Parse(txtcno.Text);
                     query1 = "select * from [vidhu].[Policy] where Customerno= " + cno;
                    com.CommandText = query1;

                }
                else if(txtpno.Text != "")
                {
                    pno = int.Parse(txtpno.Text);
                    query1 = "select * from [vidhu].[Policy] where Policyno= " + pno;
                    com.CommandText = query1;

                }
                
                SqlDataReader Reader = com.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(Reader);
                Dgrid.DataContext = table;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            loadgrid();
        }

        private void nplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from SearchPolicy page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
