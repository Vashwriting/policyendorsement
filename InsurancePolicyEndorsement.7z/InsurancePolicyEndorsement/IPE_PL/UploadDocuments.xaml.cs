﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using IPE_Entity;
using IPE_Exception;
using IPE_BLL;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for UploadDocuments.xaml
    /// </summary>
    public partial class UploadDocuments : Page
    {
        public UploadDocuments()
        {
            InitializeComponent();
        }

        string imageName, strName;

        private void butupload_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;

            if (imageName != "")
            {
                //Initialize a file stream to read the image file
                FileStream fs = new FileStream(imageName, FileMode.Open, FileAccess.Read);

                //Initialize a byte array with size of stream
                imgByteArr = new byte[fs.Length];

                //Read data from the file stream and put into the byte array
                fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                //Close a file stream
                fs.Close();
            }


            Documents d = new Documents();
            d.PolicyNumber = Int32.Parse(txtpno.Text);
            d.SelecttheCard = cmbsc.Text;
            d.Photo = imgByteArr;

            AddDetails(d);
        }

            private static void AddDetails(Documents d)
            {
                try
                {
                    bool Cardadded = Documents_BLL.UploadBLL(d);
                    if (Cardadded)
                    {
                        MessageBox.Show("Uploaded Successfully");

                    }
                    else
                        MessageBox.Show("Card not Uploaded");
                }
                catch (PolicyException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        private void nplHome_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from UploadDocument page to Home page
            this.NavigationService.Navigate(new Uri("Home.xaml", UriKind.RelativeOrAbsolute));
        }

        private void butbrowse_Click(object sender, RoutedEventArgs e)
        {
            //click event for the browse button
            try
            {
                FileDialog fldlg = new OpenFileDialog();
                fldlg.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();
                fldlg.Filter = "Images (*.jpg,*.png)|*.jpg;*.png|All Files(*.*)|*.*";
                fldlg.ShowDialog();
                {
                    strName = fldlg.SafeFileName;
                    imageName = fldlg.FileName;
                    ImageSourceConverter isc = new ImageSourceConverter();
                    imgupload.SetValue(Image.SourceProperty, isc.ConvertFromString(imageName));
                }
                fldlg = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        } 
    }
}
