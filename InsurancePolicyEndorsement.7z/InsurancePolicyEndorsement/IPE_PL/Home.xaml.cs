﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IPE_PL
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
        }

        private void hplSearch_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to SearchPolicy page
            this.NavigationService.Navigate(new Uri("SearchPolicy.xaml", UriKind.RelativeOrAbsolute));
        }

        private void hplView_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to ViewPolicy page
            this.NavigationService.Navigate(new Uri("ViewPolicy.xaml", UriKind.RelativeOrAbsolute));
        }

        private void hplUpdate_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to UpdatePage page
            this.NavigationService.Navigate(new Uri("UpdatePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void hplUpload_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to UploadDocuments page
            this.NavigationService.Navigate(new Uri("UploadDocuments.xaml", UriKind.RelativeOrAbsolute));
        }

        //private void hplEndorsment_Click(object sender, RoutedEventArgs e)
        //{
        //    //Navigating from Home page to ViewEndorsmentStatus page
        //    this.NavigationService.Navigate(new Uri("ViewEndorsmentStatus.xaml", UriKind.RelativeOrAbsolute));
        //}

        private void hpldelete_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to DeletePolicy page
            this.NavigationService.Navigate(new Uri("DeletePolicy.xaml", UriKind.RelativeOrAbsolute));
        }

        private void hpladd_Click(object sender, RoutedEventArgs e)
        {
            //Navigating from Home page to AddPolicy page
            this.NavigationService.Navigate(new Uri("AddPolicy.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
