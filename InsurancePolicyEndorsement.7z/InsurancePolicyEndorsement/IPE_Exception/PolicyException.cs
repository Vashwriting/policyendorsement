﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Exception
{

    [Serializable]
    public class PolicyException : Exception
    {
        public PolicyException() { }
        public PolicyException(string message) : base(message) { }
        public PolicyException(string message, Exception inner) : base(message, inner) { }
        protected PolicyException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
