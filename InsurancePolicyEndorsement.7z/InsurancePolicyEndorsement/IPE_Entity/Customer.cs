﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Entity
{
    public class Customer
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string telephone { get; set; }
        public string gender { get; set; }
        public DateTime DOB { get; set; }
        public string Smoker { get; set; }
        public string Hobbies { get; set; }
        public int Loginid { get; set; }
        public string Password { get; set; }
        public string ConfrimPassword { get; set; }
    }
}
