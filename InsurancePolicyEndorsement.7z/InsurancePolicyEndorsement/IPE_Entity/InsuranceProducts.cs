﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Entity
{
    public class InsuranceProducts
    {
        public int PolicyNumber { get; set; }
        public string ProductLine { get; set; }
        public string ProductName { get; set; }
        public string InsuredName { get; set; }
        public int InsuredAge { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Nominee { get; set; }
        public string Relation { get; set; }
        public string Smoker { get; set; }
        public string Address { get; set; }
        public string Telephone { get; set; }
        public string PremiumPaymentfrequency { get; set; }
    }
}
