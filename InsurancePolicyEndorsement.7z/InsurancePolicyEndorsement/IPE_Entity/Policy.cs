﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Entity
{
    public class Policy
    {
        public int PolicyNumber { get; set; }
        public int CustomerNumber { get; set; }
        public int Productid { get; set; }
        public string Planname { get; set; }
        public int Policyterm { get; set; }
        public int Payterm { get; set; }
        public int TotalPayout { get; set; }
        public int SumAssured { get; set; }
        public int BasePremium { get; set; }
        public int TotalPremium { get; set; }
    }
}
