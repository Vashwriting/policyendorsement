﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Entity
{
    public class Login
    {
        public int LoginID { get; set; }
        public int Password { get; set; }
    }
}
