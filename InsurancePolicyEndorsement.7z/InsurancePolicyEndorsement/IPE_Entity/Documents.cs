﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPE_Entity
{
    public class Documents
    {
        public int PolicyNumber { get; set; }
        public string SelecttheCard { get; set; }
        public byte[] Photo { get; set; }
    }
}
