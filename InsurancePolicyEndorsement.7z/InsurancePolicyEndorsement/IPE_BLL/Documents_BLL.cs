﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPE_Entity;
using IPE_Exception;
using IPE_DAL;

namespace IPE_BLL
{
    public class Documents_BLL
    {
        public static bool UploadBLL(Documents newuser)
        {
            bool Cardadded = false;
            try
            {
                Documents_DAL c = new Documents_DAL();
                Cardadded = c.UploadDAL(newuser);
            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Cardadded;
        }
    }
}
