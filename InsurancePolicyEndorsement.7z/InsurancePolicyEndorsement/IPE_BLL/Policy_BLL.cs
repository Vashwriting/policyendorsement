﻿using IPE_DAL;
using IPE_Entity;
using IPE_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPE_BLL
{
    public class Policy_BLL
    {
        private static bool ValidatePolicy(Policy p)
        {
            //Validations for policy details
            StringBuilder sb = new StringBuilder();
            bool validPolicy = true;
            if (p.PolicyNumber <= 1000 )
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Policy no. Require 4 digits ");

            }
            if (p.CustomerNumber <= 10000)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Customer no. Require 5 digits");

            }
            if (p.Productid <=100)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Productid Require 3 Digits");
            }
            if (!(Regex.IsMatch(p.Planname, "[A-Z][a-z]{3,}")))
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Plan Name must have only characters starting with uppercase");
            }
            if (p.Policyterm <= 10)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Policy Term should be more than 10");
            }
            if (p.Payterm <= 10)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Pay Term should be more than 10");
            }
            if (p.TotalPayout <= 1000000)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Total Payout should be more than 1000000");
            }
            if (p.SumAssured <= 1000000)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Sum Assured should be more than 1000000");
            }
            if (p.BasePremium <= 500)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Base Premium should be more than 500");
            }
            if (p.TotalPremium <= 500)
            {
                validPolicy = false;
                sb.Append(Environment.NewLine + "Total Premium should be more than 500");
            }

            if (validPolicy == false)
                throw new PolicyException(sb.ToString());
            return validPolicy;
        }

        public static Policy SearchPolicyBLL(Policy p)
        {
            //search method for policy
            Policy searchPolicy = null ;
            try
            {
                Policy_DAL c = new Policy_DAL();
                if (ValidatePolicy(p))
                {
                    searchPolicy = c.SearchPolicyDAL(p);
                }
                
            }
            catch (PolicyException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPolicy;
        }

        public static bool UpdatePolicyBLL(Policy p)
        {
            //Update method for policy
            bool UpdatePolicy = false;
            try
            {
                Policy_DAL updatep = new Policy_DAL();
                if (ValidatePolicy(p))
                {
                    UpdatePolicy = updatep.UpdatePolicyDAL(p);
                }
            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return UpdatePolicy;

        }

        public static bool DeletePolicyBLL(int cno, int pno)
        {
            //Delete method for policy
            bool Policydeleted = false;
            try
            {
                Policy_DAL PolicyDAL = new Policy_DAL();
                Policydeleted = PolicyDAL.DeletePolicyDAL(cno, pno);
            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Policydeleted;
        }

        public static bool AddPolicyBLL(Policy p)
        {
            //Add method for policy
            bool Personadded = false;
            try
            {
                Policy_DAL c = new Policy_DAL();
                if (ValidatePolicy(p))
                {
                    Personadded = c.AddPolicyDAL(p);
                }
               
            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Personadded;
        }
    }
}
