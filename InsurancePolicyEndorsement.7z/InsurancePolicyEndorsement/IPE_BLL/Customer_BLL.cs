﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPE_Entity;
using IPE_Exception;
using IPE_DAL;
using System.Text.RegularExpressions;

namespace IPE_BLL
{
    public class Customer_BLL
    {
        //Validations for Customers to Register for the policy
        private static bool ValidateCustomer(Customer c)
        {

            StringBuilder sb = new StringBuilder();
            bool ValidateCustomer = true;
            
            if (!(Regex.IsMatch(c.Name, "[A-Z][a-z]{3,}")))
            {
                ValidateCustomer = false;
                sb.Append("Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (c.Address == string.Empty)
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Require Address");
            }

            if (!Regex.Match(c.telephone, @"^[8-9]{1}[0-9]{9}$").Success) 
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Phone no. Require 10 Digits and should start with 8 or 9");
            }

            if (c.gender == string.Empty)
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + " gender cannot be blank ");
            }

            if (c.Smoker == string.Empty)
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Smoker cannot be blank");
            }

            if (!Regex.Match(c.Hobbies, @"^[a-zA-Z]+$").Success)
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Hobbies cannot be blank");
            }

            if (c.DOB >= DateTime.Now)
            {
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Dob Cant be Empty");
            }

            if (!Regex.Match(c.Password, @"^[0-9]{4,}$").Success)
            {    
                ValidateCustomer = false;
                sb.Append(Environment.NewLine + "Password should contain atleast 4 digits");
            }

            if (ValidateCustomer == false)
                throw new PolicyException(sb.ToString());
            return ValidateCustomer;
        }

        public static bool customerBLL(Customer c)
        {
            //Add method for the customers to register
            bool Personadded = false;
            try
            {
                Customer_DAL p = new Customer_DAL();
                if (ValidateCustomer(c))
                {
                    Personadded = p.customerDAL(c);
                }
                
            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Personadded;
        }
    }
}
