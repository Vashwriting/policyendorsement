﻿using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for EmployeeRegistration.xaml
    /// </summary>
    public partial class EmployeeDetailsUpdate : Page
    {
        Emp_BAL emp = new Emp_BAL();
        public EmployeeDetailsUpdate()
        {
            InitializeComponent();
        }



        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            bool empAdded= false;
            if(String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtEmpFirstName.Text) || String.IsNullOrEmpty(txtAccNo.Text) || String.IsNullOrEmpty(txtEmpLastName.Text) || String.IsNullOrEmpty(txtLocation.Text))
            {
                MessageBox.Show("Feilds Cannot be Empty.");
            }
            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtAccNo.Text))
            {
                for (int i = 0; i < txtAccNo.Text.Length; i++)
                {
                    if (!char.IsNumber(txtAccNo.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Account Number.");
                        i = txtAccNo.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtEmpFirstName.Text))
            {
                for (int i = 0; i < txtEmpFirstName.Text.Length; i++)
                {
                    if (!char.IsLetter(txtEmpFirstName.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in First Name.");
                        i = txtEmpFirstName.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtEmpLastName.Text))
            {
                for (int i = 0; i < txtEmpLastName.Text.Length; i++)
                {
                    if (!char.IsLetter(txtEmpLastName.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Last Name.");
                        i = txtEmpLastName.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtLocation.Text))
            {
                for (int i = 0; i < txtLocation.Text.Length; i++)
                {
                    if (!char.IsLetter(txtLocation.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Location.");
                        i = txtLocation.Text.Length + 1;
                    }
                }
            }
            if (int.Parse(txtEmpID.Text) <= 0)
            {
                MessageBox.Show("Employee Id Cannot be 0 or less.");
            }
            if(int.Parse(txtAccNo.Text) <= 0)
            {
                MessageBox.Show("Account number Cannot be 0 or less.");
            }
            else
            {
                Emp_Entity newemp = new Emp_Entity();
                try
                {
                    newemp.Employee_ID = int.Parse(txtEmpID.Text);
                    newemp.FirstName = txtEmpFirstName.Text;
                    newemp.LastName = txtEmpLastName.Text;
                    newemp.Location = txtLocation.Text;
                    newemp.Reimburse_Account_No = int.Parse(txtAccNo.Text);
                     empAdded = emp.Emp_UpdateBAL(newemp);
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot Update record");
                }
               
                if (empAdded)
                {
                    MessageBox.Show("Updated Sccessfully");
                }
                
            }
            LoadGrid();
            
        }

        //private void btnSearch_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        Emp_BAL emp_BAL = new Emp_BAL();
        //        Emp_Entity searchedemp = new Emp_Entity();
        //        int empserach = Int32.Parse(txtEmpID.Text);
        //        searchedemp = emp_BAL.Emp_BAL_SearchEmp(empserach);

        //        if (searchedemp != null)
        //        {
        //            txtEmpID.Text = searchedemp.Employee_ID.ToString();
        //            txtEmpFirstName.Text = searchedemp.FirstName;
        //            txtEmpLastName.Text = searchedemp.LastName;
        //            txtLocation.Text = searchedemp.Location;
        //            txtAccNo.Text = searchedemp.Reimburse_Account_No.ToString();
        //        }
        //        else
        //        {
        //            MessageBox.Show("No Such Record found");
        //        }
        //    }
        //    catch (Exception)
        //    {

        //        MessageBox.Show("Cannot Search.");
        //    }
           
        //}

        public void LoadGrid()
        {
            Emp_BAL emp = new Emp_BAL();
            DataSet dataset = emp.LoadGrid_Employees_BAL();
            dgEmployees.DataContext = dataset.Tables[0];
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void dgEmployees_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;
            DataRowView row_selected = dataGrid.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                txtEmpID.Text = row_selected[0].ToString();
                txtEmpFirstName.Text = row_selected[1].ToString();
                txtEmpLastName.Text = row_selected[2].ToString();
                txtLocation.Text = row_selected[3].ToString();  
                txtAccNo.Text = Convert.ToInt32(row_selected[4]).ToString();
            }
            else
            {
                MessageBox.Show("Unable to select this row");
            }
        }
    }
}
