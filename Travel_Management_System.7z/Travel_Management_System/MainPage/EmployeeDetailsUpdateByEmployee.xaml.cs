﻿using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace MainPage
{
    /// <summary>
    /// Interaction logic for EmployeeDetailsUpdateByEmployee.xaml
    /// </summary>
    public partial class EmployeeDetailsUpdateByEmployee : Page
    {
        int empID,ReimbNo;
        string fname, lname, loc, pwd;
        Emp_BAL emp = new Emp_BAL();
        public EmployeeDetailsUpdateByEmployee()
        {
            InitializeComponent();
        }
        public EmployeeDetailsUpdateByEmployee(Emp_Entity val) : this()
        {
            if (val != null)
            {
                empID = val.Employee_ID;
                fname = val.FirstName;
                lname = val.LastName;
                loc = val.Location;
                ReimbNo = val.Reimburse_Account_No;
                pwd = val.Password;
            }
         
            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtEmpFirstName.Text) || String.IsNullOrEmpty(txtAccNo.Text) || String.IsNullOrEmpty(txtEmpLastName.Text) || String.IsNullOrEmpty(txtLocation.Text)|| String.IsNullOrEmpty(txtPwd.Text))
            {
                MessageBox.Show("Feilds Cannot be Empty.");
            }

            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }
            if(!String.IsNullOrEmpty(txtEmpID.Text))
            {
                if (int.Parse(txtEmpID.Text) <= 0)
                {
                    MessageBox.Show("Employee Id Cannot be 0 or less.");
                }
            }

            if (!String.IsNullOrEmpty(txtAccNo.Text))
            {
                for (int i = 0; i < txtAccNo.Text.Length; i++)
                {
                    if (!char.IsNumber(txtAccNo.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Account Number.");
                        i = txtAccNo.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtEmpFirstName.Text))
            {
                for (int i = 0; i < txtEmpFirstName.Text.Length; i++)
                {
                    if (!char.IsLetter(txtEmpFirstName.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in First Name.");
                        i = txtEmpFirstName.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtEmpLastName.Text))
            {
                for (int i = 0; i < txtEmpLastName.Text.Length; i++)
                {
                    if (!char.IsLetter(txtEmpLastName.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Last Name.");
                        i = txtEmpLastName.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtLocation.Text))
            {
                for (int i = 0; i < txtLocation.Text.Length; i++)
                {
                    if (!char.IsLetter(txtLocation.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Location.");
                        i = txtLocation.Text.Length + 1;
                    }
                }
            }
            
            if (int.Parse(txtAccNo.Text) <= 0)
            {
                MessageBox.Show("Account number Cannot be 0 or less.");
            }
            else
            {
                bool empAdded = false;
                Emp_Entity newemp = new Emp_Entity();
                try
                {
                    newemp.Employee_ID = int.Parse(txtEmpID.Text);
                    newemp.FirstName = txtEmpFirstName.Text;
                    newemp.LastName = txtEmpLastName.Text;
                    newemp.Location = txtLocation.Text;
                    newemp.Reimburse_Account_No = int.Parse(txtAccNo.Text);
                    newemp.Password = txtPwd.Text;
                    empAdded = emp.Emp_UpdatebyEmpBAL(newemp);
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message + "Employee");
                }

                catch (Exception)
                {
                    MessageBox.Show("Cannot Update the Record");
                }

                if (empAdded)
                {
                    MessageBox.Show("Updated Sccessfully");
                }
            }
            
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            txtEmpID.Text =empID.ToString();
            txtEmpFirstName.Text = fname;
            txtEmpLastName.Text = lname;
            txtLocation.Text = loc;
            txtAccNo.Text = ReimbNo.ToString();
            txtPwd.Text = pwd;

        }
    }
}
