﻿using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;
using EmployeeTravelRequestEntity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for TravelRequestUpdatePage.xaml
    /// </summary>
    public partial class TravelRequestUpdatePage : Page
    {
        int empid;
       
        public TravelRequestUpdatePage()
        {
            InitializeComponent();
        }

        public TravelRequestUpdatePage(Emp_Entity val) : this()
        {
            empid = val.Employee_ID;
            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }
        
       public void Loadgrid()
        {
            TReq_BAL req = new TReq_BAL();
            DataSet dataset = new DataSet();
            dataset = req.TravelRequestUpdate_LoadGrid_BAL(empid);
            dgTravelReqUpdate.DataContext = dataset.Tables[0];
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            txtEmpID.Text = empid.ToString();
            txtApplyDate.Text = DateTime.Now.ToString();
            Loadgrid();
        }

        //private void btnSearch_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        int MR_no = int.Parse(txtMR_no.Text);
        //        TravelRequest searchedTR = new TravelRequest();
        //        TReq_BAL req = new TReq_BAL();
        //        searchedTR = req.SearchTravelRequest_BAL(MR_no);

        //        if (searchedTR.Request_Status == "Pending")
        //        {
        //            txtEmpID.Text = searchedTR.Employee_ID.ToString();
        //            txtMR_no.Text = searchedTR.MR_Number.ToString();
        //            txtApplyDate.Text = (DateTime.Now).ToString();
        //            txtFromCity.Text = searchedTR.From_city.ToString();
        //            txtToCity.Text = searchedTR.To_City.ToString();
        //            txtTravelDate.Text = Convert.ToDateTime(searchedTR.Travel_Date).ToString();
        //            // txtTravelMode.Text = searchedTR.Travel_Mode.ToString();
        //            txtReason.Text = searchedTR.Reason_For_Travel.ToString();
        //            txtTravelDuration.Text = searchedTR.Travel_Duration.ToString();
        //        }
        //        else
        //        {
        //            MessageBox.Show("Sorry!! You cannot Modify your request now.Because it is already " + searchedTR.Request_Status);
        //        }
        //    }
        //    catch (Emp_Exception)
        //    {
        //        MessageBox.Show("No such record present.");
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Cannot Search.");
        //    }
            

       
        //}

        private void btnRequestUpdate_Click(object sender, RoutedEventArgs e)
        {
            if(String.IsNullOrEmpty(txtApplyDate.Text) || String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtFromCity.Text) || String.IsNullOrEmpty(txtMR_no.Text) || String.IsNullOrEmpty(txtReason.Text) || String.IsNullOrEmpty(txtToCity.Text) || String.IsNullOrEmpty(txtTravelDate.Text) || String.IsNullOrEmpty(txtTravelDuration.Text) || String.IsNullOrEmpty(txtTravelMode.Text))
            {
                MessageBox.Show("Fields Cannot be Empty");
            }
            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtMR_no.Text))
            {
                for (int i = 0; i < txtMR_no.Text.Length; i++)
                {
                    if (!char.IsNumber(txtMR_no.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in MR Number.");
                        i = txtMR_no.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtFromCity.Text))
            {
                for (int i = 0; i < txtFromCity.Text.Length; i++)
                {
                    if (!char.IsLetter(txtFromCity.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in from City.");
                        i = txtFromCity.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtToCity.Text))
            {
                for (int i = 0; i < txtToCity.Text.Length; i++)
                {
                    if (!char.IsLetter(txtToCity.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in To city.");
                        i = txtToCity.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtTravelDuration.Text))
            {
                for (int i = 0; i < txtTravelDuration.Text.Length; i++)
                {
                    if (!char.IsNumber(txtTravelDuration.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Travel Duration.");
                        i = txtTravelDuration.Text.Length + 1;
                    }
                }
            }

            else if (int.Parse(txtTravelDuration.Text) <= 0)
            {
                MessageBox.Show("Travel Duration Cannot be 0 or less.");
            }
            else if (int.Parse(txtMR_no.Text) <= 0)
            {
                MessageBox.Show("MR Number Cannot be 0 or less.");
            }
            else if (int.Parse(txtEmpID.Text) <= 0)
            {
                MessageBox.Show("Employee ID cannot be 0 or less.");
            }
            else
            {
                TravelRequest tr = new TravelRequest();
                try
                {
                    tr.MR_Number = int.Parse(txtMR_no.Text);
                    tr.Employee_ID = empid;
                    tr.Apply_Date = Convert.ToDateTime(txtApplyDate.Text);
                    tr.Reason_For_Travel = txtReason.Text;
                    tr.Travel_Date = Convert.ToDateTime(txtTravelDate.Text);
                    tr.Travel_Mode = txtTravelMode.Text;
                    tr.From_city = txtFromCity.Text;
                    tr.To_City = txtToCity.Text;
                    tr.Travel_Duration = int.Parse(txtTravelDuration.Text);
                    tr.Request_Status = "Pending";


                    bool requestAdded = TReq_BAL.UpdateTravelRequest_BAL(tr);

                    if (requestAdded)
                    {
                        MessageBox.Show("Updated Successfully");
                    }
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message + "Travel Request");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "Travel Request");
                }
            }
            
        }

        private void dgTravelReqUpdate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
                DataGrid dg = (DataGrid)sender;
                DataRowView row_selected = dg.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                if (row_selected[9].ToString() == "Pending")
                {
                    txtTravelDuration.Text = row_selected[8].ToString();
                    txtEmpID.Text = row_selected[1].ToString();
                    txtMR_no.Text = row_selected[0].ToString();
                    txtApplyDate.Text = Convert.ToDateTime(row_selected[2]).ToString();
                    txtFromCity.Text = row_selected[6].ToString();
                    txtToCity.Text = row_selected[7].ToString();
                    txtTravelDate.Text = Convert.ToDateTime(row_selected[4]).ToString();
                    txtTravelMode.Text = row_selected[5].ToString();
                    txtReason.Text = row_selected[3].ToString();
                }
                else
                {
                    MessageBox.Show("Sorry!! You cannot Modify your request now.Because it is Already " +row_selected[9].ToString());
                }
            
            }
        }
    }
}
