﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for Page2.xaml
    /// </summary>
    public partial class AdminLogin : Page
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if(String.IsNullOrWhiteSpace(username.Text) || String.IsNullOrEmpty(password.Text))
            {
                MessageBox.Show("Please Enter username and Password correctly.");
            }
            else
            {
                if (ValidateAdmin())
                {
                    MessageBox.Show("Admin Logged in");
                    this.NavigationService.Navigate(new Uri("AdminPage.xaml", UriKind.RelativeOrAbsolute));
                }
                else
                {
                    MessageBox.Show("Incorrect Credentials");
                }
            }
        }

        private bool ValidateAdmin()
        {
            bool validAdmin = false ;
            if (username.Text == "admin" && password.Text == "admin")
            {
                validAdmin = true;
            }
            else validAdmin = false;
            return validAdmin;
            

        }
    }
}
