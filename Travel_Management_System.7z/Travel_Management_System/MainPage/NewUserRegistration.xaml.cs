﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for NewUserRegistration.xaml
    /// </summary>
    public partial class NewUserRegistration : Page
    {
        Emp_BAL emp = new Emp_BAL();
        public NewUserRegistration()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {

            if (String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtAccNo.Text) || String.IsNullOrEmpty(txtEmpFirstName.Text) || String.IsNullOrEmpty(txtEmpLastName.Text) || String.IsNullOrEmpty(txtLocation.Text) || String.IsNullOrEmpty(txtPwd.Text))
            {
                MessageBox.Show("Fields Cannot be Empty.");
            }

            //else if (!String.IsNullOrEmpty(txtEmpID.Text) || !String.IsNullOrEmpty(txtAccNo.Text) || !String.IsNullOrEmpty(txtEmpFirstName.Text) || !String.IsNullOrEmpty(txtEmpLastName.Text) || !String.IsNullOrEmpty(txtLocation.Text) || !String.IsNullOrEmpty(txtPwd.Text))
            //{
            //    if (!String.IsNullOrEmpty(txtEmpID.Text))
            //    {
            //        for (int i = 0; i < txtEmpID.Text.Length; i++)
            //        {
            //            if (!char.IsNumber(txtEmpID.Text[i]))
            //            {
            //                MessageBox.Show("Incorrect Type of value in Employee ID.");
            //                i = txtEmpID.Text.Length + 1;
            //            }

            //        }
            //    }
            //    else if (int.Parse(txtEmpID.Text) <= 0)
            //    {
            //        MessageBox.Show("Employee Id Cannot be 0 or less.");
            //    }


            //    if (!String.IsNullOrEmpty(txtAccNo.Text))
            //    {
            //        for (int i = 0; i < txtAccNo.Text.Length; i++)
            //        {
            //            if (!char.IsNumber(txtAccNo.Text[i]))
            //            {
            //                MessageBox.Show("Incorrect Type of value in Account Number.");
            //                i = txtAccNo.Text.Length + 1;
            //            }
            //        }
            //    }
            //    else if (int.Parse(txtAccNo.Text) <= 0)
            //    {
            //        MessageBox.Show("Account Number Cannot be 0 or less.");
            //    }


            //    if (!String.IsNullOrEmpty(txtEmpFirstName.Text))
            //    {
            //        for (int i = 0; i < txtEmpFirstName.Text.Length; i++)
            //        {
            //            if (!char.IsLetter(txtEmpFirstName.Text[i]))
            //            {
            //                MessageBox.Show("Incorrect Type of value in First Name.");
            //                i = txtEmpFirstName.Text.Length + 1;
            //            }
            //        }
            //    }
            //    if (!String.IsNullOrEmpty(txtEmpLastName.Text))
            //    {
            //        for (int i = 0; i < txtEmpLastName.Text.Length; i++)
            //        {
            //            if (!char.IsLetter(txtEmpLastName.Text[i]))
            //            {
            //                MessageBox.Show("Incorrect Type of value in Last Name.");
            //                i = txtEmpLastName.Text.Length + 1;
            //            }
            //        }
            //    }
            //    if (!String.IsNullOrEmpty(txtLocation.Text))
            //    {
            //        for (int i = 0; i < txtLocation.Text.Length; i++)
            //        {
            //            if (!char.IsLetter(txtLocation.Text[i]))
            //            {
            //                MessageBox.Show("Incorrect Type of value in Location.");
            //                i = txtLocation.Text.Length + 1;
            //            }
            //        }
            //    }

            //}


            else
            {
                try
                {
                    Emp_Entity Emp = new Emp_Entity();

                    Emp.Employee_ID = int.Parse(txtEmpID.Text);
                    Emp.FirstName = txtEmpFirstName.Text;
                    Emp.LastName = txtEmpLastName.Text;
                    Emp.Location = txtLocation.Text;
                    Emp.Reimburse_Account_No = int.Parse(txtAccNo.Text);
                    Emp.Password = txtPwd.Text;

                    bool empAdded = emp.Emp_RegisterBAL(Emp);

                    if (empAdded)
                    {
                        MessageBox.Show("Registered Sccessfully");
                    }

                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message, "New User Registration");
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "New User Registration");
                }

            }

        }
    }
}
