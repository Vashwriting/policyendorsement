﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntity;
using EmployeeException;
using EmployeeTravelRequestEntity;
using ExpenseRequestEntity;

namespace EmployeeDAL
{
    public class Emp_DAL
    {
        //bool Emp_Registered = false;

        static string Constring = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(Constring);
        SqlCommand Command = new SqlCommand();


        public DataSet LoadGrid_Employees_DAL()
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();
            SqlCommand Command = new SqlCommand();
            Command.Connection = connection;
            connection.Open();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM  Project_172455_Employee", connection);
            sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            sqlCommandBuilder.DataAdapter = sqlDataAdapter;
            DataSet dataset = new DataSet();
            sqlDataAdapter.Fill(dataset);
            return dataset;
        }


        public bool Emp_Register(Emp_Entity Emp)
        {
           

            bool Emp_Registered = false;

            try
            {

                connection.Open();
                Command = new SqlCommand("udp_Project_172455_AddEmployee", connection);
                Command.Parameters.AddWithValue("@Employee_ID", Emp.Employee_ID);
                Command.Parameters.AddWithValue("@FirstName", Emp.FirstName);
                Command.Parameters.AddWithValue("@LastName", Emp.LastName);
                Command.Parameters.AddWithValue("@Location", Emp.Location);
                Command.Parameters.AddWithValue("@Reimburse_Account_No", Emp.Reimburse_Account_No);
                Command.Parameters.AddWithValue("@Password", Emp.Password);

                Command.CommandType = CommandType.StoredProcedure;
                int added = Command.ExecuteNonQuery();

                if (added == 1)
                    Emp_Registered = true;
                else
                    Emp_Registered = false;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            
            return Emp_Registered;
        }

        public bool Emp_UpdateDAL(Emp_Entity upemp)
        {

            bool Emp_Updated = false;

            try
            {
                connection.Open();

                Command = new SqlCommand("udp_Project_172455_UpdateEmployee", connection);
                Command.Parameters.AddWithValue("@Employee_ID", upemp.Employee_ID);
                Command.Parameters.AddWithValue("@FirstName", upemp.FirstName);
                Command.Parameters.AddWithValue("@LastName", upemp.LastName);
                Command.Parameters.AddWithValue("@Location", upemp.Location);
                Command.Parameters.AddWithValue("@Reimburse_Account_No", upemp.Reimburse_Account_No);
               
                Command.CommandType = CommandType.StoredProcedure;
                int updated = Command.ExecuteNonQuery();

                if (updated == 1)
                    Emp_Updated = true;
                else
                    Emp_Updated = false;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
            return Emp_Updated;
        }


        public bool Emp_UpdatebyEmpDAL(Emp_Entity upemp)
        {

            bool Emp_Updated = false;

            try
            {
                connection.Open();

                Command = new SqlCommand("udp_Project_172455_UpdatebyEmpEmployee", connection);
                Command.Parameters.AddWithValue("@Employee_ID", upemp.Employee_ID);
                Command.Parameters.AddWithValue("@FirstName", upemp.FirstName);
                Command.Parameters.AddWithValue("@LastName", upemp.LastName);
                Command.Parameters.AddWithValue("@Location", upemp.Location);
                Command.Parameters.AddWithValue("@Reimburse_Account_No", upemp.Reimburse_Account_No);
                Command.Parameters.AddWithValue("@Password", upemp.Password);

                Command.CommandType = CommandType.StoredProcedure;
                int updated = Command.ExecuteNonQuery();

                if (updated == 1)
                    Emp_Updated = true;
                else
                    Emp_Updated = false;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
            return Emp_Updated;
        }

        public Emp_Entity Emp_Login_DAL(string uname, string pwd)
        {
            Emp_Entity employee = new Emp_Entity();

            connection.Open();

            try
            {
                Command = new SqlCommand("udp_Project_172455_LoginEmployee", connection);
                Command.Parameters.AddWithValue("@Employee_ID", uname);
                Command.Parameters.AddWithValue("@Password", pwd);
                Command.CommandType = CommandType.StoredProcedure;

                SqlDataReader reader = Command.ExecuteReader();

                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        employee.Employee_ID = int.Parse(reader[0].ToString());
                        employee.FirstName = reader[1].ToString();
                        employee.LastName = reader[2].ToString();
                        employee.Location = reader[3].ToString();
                        employee.Reimburse_Account_No = int.Parse(reader[4].ToString());
                        employee.Password = reader[5].ToString();
                    }

                }
                else
                {
                    throw new Emp_Exception();
                }

            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

            return employee;

        }


        //public Emp_Entity Emp_DAL_SearchEmp(int empid)
        //{
        //    int idtosearch = empid;

        //    Emp_Entity employee = new Emp_Entity();

        //    connection.Open();

        //    try
        //    {


        //        Command = new SqlCommand("udp_Project_172455_SearchEmployee", connection);
        //        Command.Parameters.AddWithValue("@Employee_ID", empid);
        //        Command.CommandType = CommandType.StoredProcedure;

        //        SqlDataReader reader = Command.ExecuteReader();

        //        if (reader.HasRows)
        //        {

        //            while (reader.Read())
        //            {
        //                employee.Employee_ID = int.Parse(reader[0].ToString());
        //                employee.FirstName = reader[1].ToString();
        //                employee.LastName = reader[2].ToString();
        //                employee.Location = reader[3].ToString();
        //                employee.Reimburse_Account_No = int.Parse(reader[4].ToString());
        //                employee.Password = reader[5].ToString();

        //            }

        //        }

        //    }
            
        //    catch (Emp_Exception)
        //    {
        //        throw;
        //    }
        //    catch (SqlException)
        //    {
        //        throw;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }

        //    return employee;
        //}

       
    }
    

    public class ExpenseDAL
    {
        static string Constring = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(Constring);
        SqlCommand Command = new SqlCommand();


        public int ExpenseRequestCount_DAL()
        {
            int count = 0;
            try
            {
                SqlCommand Command = new SqlCommand();
                connection.Open();
                Command = new SqlCommand("Select Count(*) from Project_172455_ExpenseDetails Where Expense_Status='Pending'", connection);
                count = int.Parse(Command.ExecuteScalar().ToString());
            }
            catch (Exception)
            {

            }
            finally
            {
                connection.Close();
            }
            return count;
        }

        public DataSet LoadGrid_PendingExpenseDetails_DAL()
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();

            Command.Connection = connection;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Project_172455_ExpenseDetails where Expense_Status='Pending'", connection);
            sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            sqlCommandBuilder.DataAdapter = sqlDataAdapter;
            DataSet dataset = new DataSet();
            sqlDataAdapter.Fill(dataset);
            return dataset;
        }

        public bool ExpenseRequestGen_DAL(ExpenseRequest er)
        {
            bool reqAdd = false;
            try
            {
                connection.Open();

                Command = new SqlCommand("udp_Project_172455_AddExpenseRequest1", connection);

                Command.Parameters.AddWithValue("@Employee_ID", er.Employee_ID);
                Command.Parameters.AddWithValue("@Expense_Report_ID", er.ExpenseReport_ID);
                Command.Parameters.AddWithValue("@Expense_Type", er.Expense_Type);
                Command.Parameters.AddWithValue("@Expense_Date", er.Expense_Date);
                Command.Parameters.AddWithValue("@Amount_Paid", er.Amount_Paid);
                Command.Parameters.AddWithValue("@Payment_Type", er.Payment_Type);
                Command.Parameters.AddWithValue("@MR_Number", er.MR_Number);
                Command.Parameters.AddWithValue("@Reimbursement_Account_No", er.Reimbursement_Account_no);
                Command.Parameters.AddWithValue("@Expense_Status", "Pending");

                Command.CommandType = CommandType.StoredProcedure;

                int added = Command.ExecuteNonQuery();

                if (added == 1)
                    reqAdd = true;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
            return reqAdd;
        }

        public ExpenseRequest SearchExpenseRequest_DAL(int MR_number)
        {
            ExpenseRequest pendingrequest = new ExpenseRequest();

            connection.Open();

            try
            {
                SqlCommand Command;
                Command = new SqlCommand("Select * from Project_172455_ExpenseDetails where MR_Number=@MR_Number", connection);
                Command.Parameters.AddWithValue("@MR_Number", MR_number);
                //Command.CommandType = CommandType.StoredProcedure;

                SqlDataReader reader = Command.ExecuteReader();

                if (reader.HasRows)
                {

                    while (reader.Read())
                    {
                        pendingrequest.Employee_ID = int.Parse(reader[0].ToString());
                        pendingrequest.ExpenseReport_ID = int.Parse(reader[1].ToString());
                        pendingrequest.Expense_Type = reader[2].ToString();
                        pendingrequest.Expense_Date = Convert.ToDateTime(reader[3]);
                        pendingrequest.Amount_Paid = int.Parse(reader[4].ToString());
                        pendingrequest.Payment_Type = reader[5].ToString();
                        pendingrequest.MR_Number = int.Parse(reader[6].ToString());
                        pendingrequest.Reimbursement_Account_no = int.Parse(reader[7].ToString());


                    }

                }

            }
            catch (Emp_Exception ex)
            {
                throw ex;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

            return pendingrequest;
        }


        public DataSet ExpenseRequestUpdate_LoadGrid_DAL(int empid)
        {
            int searchbyID = empid;
            try
            {
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Project_172455_ExpenseDetails where Employee_ID ='" + searchbyID + "'", connection);
                sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                sqlCommandBuilder.DataAdapter = sqlDataAdapter;
                DataSet dataset = new DataSet();
                sqlDataAdapter.Fill(dataset);

                return dataset;
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool ExpenseStatus_DAL(int MR_number, string statusUpdate)
        {
            bool statusUpdated = false;
            try
            {
                connection.Open();

                Command = new SqlCommand("update Project_172455_ExpenseDetails set Expense_Status = @Expense_Status where MR_Number = @MR_Number", connection);
                Command.Parameters.AddWithValue("@MR_Number", MR_number);
                Command.Parameters.AddWithValue("@Expense_Status", statusUpdate);

                //Command.CommandType = CommandType.StoredProcedure;
                int updated = Command.ExecuteNonQuery();
                if (updated == 1)
                {
                    statusUpdated = true;
                }

            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
            return statusUpdated;
        }

        public int AutoIncrExpenseId_DAL()
        {
            int ExpenseId;
            try
            {
                SqlCommand cmd = new SqlCommand("select ident_current('Project_172455_ExpenseDetails') + ident_incr('Project_172455_ExpenseDetails')", connection);
                connection.Open();
                ExpenseId =Convert.ToInt32( cmd.ExecuteScalar());
            }
            finally
            {
                connection.Close();
            }
            return ExpenseId;
        }

        public bool UpdateExpenseRequest_DAL(ExpenseRequest tr)
        {
            bool requestAdded = false;
            connection.ConnectionString = Constring;
            try
            {
                connection.Open();

                Command = new SqlCommand("udp_Project_172455_UpdateExpenseRequest", connection);
                Command.Parameters.AddWithValue("@MR_Number", tr.MR_Number);
                Command.Parameters.AddWithValue("@Employee_ID", tr.Employee_ID);
                Command.Parameters.AddWithValue("@Amount_Paid", tr.Amount_Paid);
                Command.Parameters.AddWithValue("@Expense_Date", tr.Expense_Date);
                Command.Parameters.AddWithValue("@Expense_Type", tr.Expense_Type);
                Command.Parameters.AddWithValue("@Payment_Type", tr.Payment_Type);
                Command.Parameters.AddWithValue("@Reimbursement_Account_no", tr.Reimbursement_Account_no);
                Command.Parameters.AddWithValue("@Expense_Status", tr.Expense_Status);


                Command.CommandType = CommandType.StoredProcedure;
                int added = Command.ExecuteNonQuery();

                if (added == 1)
                {
                    requestAdded = true;
                }
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
            return requestAdded;
        }

    }


    public class TReq_DAL
    {
       
        static string connectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection Connection = new SqlConnection(connectionString);
        SqlCommand Command = new SqlCommand();

        bool requestAdded = false;

        public int TravelRequestCount_DAL()
        {
            int count=0;
            try
            {
                SqlCommand Command = new SqlCommand();
                Connection.Open();
                Command = new SqlCommand("Select Count(*) from Project_172455_TravelDetails Where Request_Status='Pending'", Connection);
                count = int.Parse(Command.ExecuteScalar().ToString());
            }
            catch (Exception)
            {

            }
            finally
            {
                Connection.Close();
            }
            return count;
        }

        public bool TravelRequest_DAL(TravelRequest tr)
        {

            Connection.ConnectionString = connectionString;
            try
            {
                Connection.Open();

                Command = new SqlCommand("udp_Project_172455_AddTravelRequest", Connection);
                Command.Parameters.AddWithValue("@MR_Number", tr.MR_Number);
                Command.Parameters.AddWithValue("@Employee_ID", tr.Employee_ID);
                Command.Parameters.AddWithValue("@Apply_Date", tr.Apply_Date);
                Command.Parameters.AddWithValue("@Reason_For_Travel", tr.Reason_For_Travel);
                Command.Parameters.AddWithValue("@Travel_Date", tr.Travel_Date);
                Command.Parameters.AddWithValue("@Travel_Mode", tr.Travel_Mode);
                Command.Parameters.AddWithValue("@From_city", tr.From_city);
                Command.Parameters.AddWithValue("@To_City", tr.To_City);
                Command.Parameters.AddWithValue("@Travel_Duration", tr.Travel_Duration);
                Command.Parameters.AddWithValue("@Request_Status", tr.Request_Status);


                Command.CommandType = CommandType.StoredProcedure;
                int added = Command.ExecuteNonQuery();

                if (added == 1)
                {
                    requestAdded = true;
                }
            }
            catch(Emp_Exception)
            {
                throw;
            }
            catch(SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Connection.Close();
            }
            return requestAdded;
        }

        public DataSet LoadGrid_PendingTravelRequests_DAL()
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();
            SqlCommand Command = new SqlCommand();
            Command.Connection = Connection;
            Connection.Open();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Project_172455_TravelDetails where Request_Status='Pending'", Connection);
            sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            sqlCommandBuilder.DataAdapter = sqlDataAdapter;
            DataSet dataset = new DataSet();
            sqlDataAdapter.Fill(dataset);
            return dataset;
        }

        public DataSet TravelRequestUpdate_LoadGrid_DAL(int empid)
        {
            int searchbyID = empid;
            try
            {
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();
                SqlCommand Command = new SqlCommand();
                Command.Connection = Connection;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Project_172455_TravelDetails where Employee_ID ='" + searchbyID + "'", Connection);
                sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                sqlCommandBuilder.DataAdapter = sqlDataAdapter;
                DataSet dataset = new DataSet();
                sqlDataAdapter.Fill(dataset);
               
                return dataset;
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Connection.Close();
            }
        }

        public bool UpdateTravelRequest_DAL(TravelRequest tr)
        {

            Connection.ConnectionString = connectionString;
            try
            {
                Connection.Open();

                Command = new SqlCommand("udp_Project_172455_UpdateTravelRequest", Connection);
                Command.Parameters.AddWithValue("@MR_Number", tr.MR_Number);
                Command.Parameters.AddWithValue("@Employee_ID", tr.Employee_ID);
                Command.Parameters.AddWithValue("@Apply_Date", tr.Apply_Date);
                Command.Parameters.AddWithValue("@Reason_For_Travel", tr.Reason_For_Travel);
                Command.Parameters.AddWithValue("@Travel_Date", tr.Travel_Date);
                Command.Parameters.AddWithValue("@Travel_Mode", tr.Travel_Mode);
                Command.Parameters.AddWithValue("@From_city", tr.From_city);
                Command.Parameters.AddWithValue("@To_City", tr.To_City);
                Command.Parameters.AddWithValue("@Travel_Duration", tr.Travel_Duration);
                Command.Parameters.AddWithValue("@Request_Status", tr.Request_Status);


                Command.CommandType = CommandType.StoredProcedure;
                int added = Command.ExecuteNonQuery();

                if (added == 1)
                {
                    requestAdded = true;
                }
            }
            catch (Emp_Exception )
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Connection.Close();
            }
            return requestAdded;
        }

        
        public bool ReuestStatus_DAL(int MR_number, string Request_Status)
        {
            bool statusUpdated = false;
            try
            {
                Connection.ConnectionString = connectionString;

                Connection.Open();

                Command = new SqlCommand("update Project_172455_TravelDetails set Request_Status = @Request_Status where MR_Number = @MR_Number", Connection);
                Command.Parameters.AddWithValue("@MR_Number", MR_number);
                Command.Parameters.AddWithValue("@Request_Status", Request_Status);

                //Command.CommandType = CommandType.StoredProcedure;
                int updated = Command.ExecuteNonQuery();
                if (updated == 1)
                {
                    statusUpdated = true;
                }

            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            finally
            {
                Connection.Close();
            }
            return statusUpdated;
        }

        //public TravelRequest SearchTravelRequest_DAL(int MR_number)
        //{
        //    TravelRequest pendingrequest = new TravelRequest();
        //    Connection.ConnectionString = connectionString;

        //    Connection.Open();

        //    try
        //    {
        //        SqlCommand Command;
        //        Command = new SqlCommand("Select * from Project_172455_TravelDetails where MR_Number=@MR_Number", Connection);
        //        Command.Parameters.AddWithValue("@MR_Number", MR_number);
        //        //Command.CommandType = CommandType.StoredProcedure;

        //        SqlDataReader reader = Command.ExecuteReader();

        //        if (reader.HasRows)
        //        {

        //            while (reader.Read())
        //            {
        //                pendingrequest.Employee_ID = int.Parse(reader[1].ToString());
        //                pendingrequest.MR_Number = int.Parse(reader[0].ToString());
        //                pendingrequest.Apply_Date = Convert.ToDateTime(reader[2]);
        //                pendingrequest.Reason_For_Travel = reader[3].ToString();
        //                pendingrequest.Travel_Date = Convert.ToDateTime(reader[4].ToString());
        //                pendingrequest.Travel_Mode = reader[5].ToString();
        //                pendingrequest.From_city = reader[6].ToString();
        //                pendingrequest.To_City = reader[7].ToString();
        //                pendingrequest.Travel_Duration = Int32.Parse(reader[8].ToString());
        //                pendingrequest.Request_Status = reader[9].ToString();
        //            }

        //        }

        //    }
        //    catch (Emp_Exception)
        //    {
        //        throw;
        //    }
        //    catch (SqlException)
        //    {
        //        throw;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        Connection.Close();
        //    }

        //        return pendingrequest;
        //}
        
    }

}
