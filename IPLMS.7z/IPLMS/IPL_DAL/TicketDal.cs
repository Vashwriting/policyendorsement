﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class TicketDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static TicketDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public TicketDal()
        {
            con = new SqlConnection(conStr);
        }
        //AddTicketDal
        public int AddTicketDal(Ticket pboj)
        {
            int pid = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Ticket_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TicketId", pboj.TicketId);
                cmd.Parameters.AddWithValue("@MatchId", pboj.MatchId);
                cmd.Parameters.AddWithValue("@CategoryId", pboj.CategoryId);
                cmd.Parameters.AddWithValue("@Price", pboj.Price);
               
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

             }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //DisplayTicketDal
        public DataTable DisplayTicketDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Ticket_display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //UpdateTicketDal
        public bool UpdateTicketDal(Ticket pbo)
        {
            bool isTicketedited = false;
            try
            {   cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Ticket_Update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TicketId", pbo.TicketId);
                cmd.Parameters.AddWithValue("@MatchId", pbo.MatchId);
                cmd.Parameters.AddWithValue("@CategoryId", pbo.CategoryId);
                cmd.Parameters.AddWithValue("@Price", pbo.Price);
                
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isTicketedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isTicketedited;

        }
        //DeleteTicketDAL
        public bool DeleteTicketDAL(string TicketId)
        {
            bool TicketDeleted = false;
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Ticket_Delete]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TicketId", TicketId);

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    TicketDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return TicketDeleted;
        }
    }
}
