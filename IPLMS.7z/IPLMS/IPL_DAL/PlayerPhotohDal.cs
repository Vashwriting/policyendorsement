﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class PlayerPhotohDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static PlayerPhotohDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public PlayerPhotohDal()
        {
            con = new SqlConnection(conStr);
        }
        //AddPlayerPhotoDal
        public int AddPlayerPhotoDal(PlayerPhoto pboj)
        {
            int pid = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[PlayerPhoto_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", pboj.PlayerId);
                cmd.Parameters.AddWithValue("@PlayerPhoto", pboj.Photo);
                
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //UpdatePlayerPhotoDal
        public bool UpdatePlayerPhotoDal(PlayerPhoto pbo)
        {
            bool isemployeeedited = false;
            try
            {  cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[PlayerPhoto_update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", pbo.PlayerId);
                cmd.Parameters.AddWithValue("@PlayerPhoto", pbo.Photo);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        //DeletePlayerPhotohDAL
        public bool DeletePlayerPhotohDAL(string @PlayerId)
        {
            bool PlayerPhotoDeleted = false;
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[PlayerPhoto_delete]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", PlayerId);

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    PlayerPhotoDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return PlayerPhotoDeleted;
        }
    }
}
