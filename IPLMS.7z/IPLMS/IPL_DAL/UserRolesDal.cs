﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class UserRolesDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static UserRolesDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public UserRolesDal()
        {
            con = new SqlConnection(conStr);
        }
        public int AddUserRolesDAL(UserRoles pboj)
        {
            int pid = 0;
            try
            {

                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[UserRoles_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserId", pboj.UserId);
                cmd.Parameters.AddWithValue("@RoleId", pboj.RoleId);
              

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
                pid = pid + 1;
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //UserRolesDisplayDal
        public DataTable UserRolesDisplayDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[UserRoles_display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //update
        public bool UpdateUserRolesDal(UserRoles pb1)
        {
            bool isUserRolesupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[UserRoles__Update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", pb1.UserId);

                cmd.Parameters.AddWithValue("@RoleId", pb1.RoleId);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isUserRolesupdate = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isUserRolesupdate;

        }

    }
}
