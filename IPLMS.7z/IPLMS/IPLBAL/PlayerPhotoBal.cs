﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class PlayerPhotoBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidatePlayerPhoto(PlayerPhoto pro)
        {
            bool IsValidProduct = true;
            if (pro.PlayerId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("PlayerId cannot be blank " + Environment.NewLine);

            }
            if (pro.PlayerId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "PlayerId should not be negative");
            }
            return IsValidProduct;
        }
        //AddPlayerPhotoBAL
        public int AddPlayerPhotoBAL(PlayerPhoto pobj)
        {
            try
            {
                int pid = 0;
                PlayerPhotohDal pd = new PlayerPhotohDal();
                if (ValidatePlayerPhoto(pobj))
                {
                    pid = pd.AddPlayerPhotoDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //UpdatePlayerPhotoBal
        public bool UpdatePlayerPhotoBal(PlayerPhoto upmatch)
        {
            bool Matchupdated = false;
            try
            {
                if (ValidatePlayerPhoto(upmatch))
                {
                    PlayerPhotohDal matchdal = new PlayerPhotohDal();//give Dal class 
                    Matchupdated = matchdal.UpdatePlayerPhotoDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
        //DeletePlayerPhotoBal
        public static bool DeletePlayerPhotoBal(string VenueId)
        {
            bool PlayerPhotoDeleted = false;
            try
            {
                PlayerPhotohDal deletedal = new PlayerPhotohDal();
                PlayerPhotoDeleted = deletedal.DeletePlayerPhotohDAL(VenueId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PlayerPhotoDeleted;
        }
    }
}
