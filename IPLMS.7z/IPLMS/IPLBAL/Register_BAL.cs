﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using IPL_DAL;

namespace IPLBAL
{
   public  class Register_BAL
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateRegister(Register_User pro)
        {
            bool ValidateRegister = true;
            if (pro.UserName.ToString().Equals(string.Empty))
            {
                ValidateRegister = false;
                sb.Append("UserName cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.UserName, @"^[A-Z,a-z]+$").Success)
            {
                ValidateRegister = false;
                sb.Append(Environment.NewLine + "UserName should be Aplhabets");
            }
            if (pro.Password.ToString().Equals(string.Empty))
            {
                ValidateRegister = false;
                sb.Append("Password cannot be blank " + Environment.NewLine);

            }
            return ValidateRegister;
        }

        public int RegisterBAL(Register_User pobj)
        {
            try
            {
                int pid = 0;
                Register_dal pd = new Register_dal();

                if (ValidateRegister(pobj))
                {
                    pid = pd.RegisterDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }

    }
}
