﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class ScheduleBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateSchedule(SchedulEntity pro)
        {


            bool IsValidSchedule = true;
            if (pro.ScheduleId.ToString().Equals(string.Empty))
            {
                IsValidSchedule = false;
                sb.Append("ScheduleId cannot be blank " + Environment.NewLine);

            }
            if (pro.ScheduleId < 1)
            {
                IsValidSchedule = false;
                sb.Append(Environment.NewLine + "ScheduleId should not be negative");
            }
            //if (!(Regex.IsMatch(pro.ScheduleId.ToString(), @"[0-9]$")))
            //{
            //    IsValidSchedule = false;
            //    sb.Append(Environment.NewLine + "ScheduleId should greater than zero");
            //}
            if (pro.MatchId.ToString().Equals(string.Empty))
            {
                IsValidSchedule = false;
                sb.Append("MatchId cannot be blank " + Environment.NewLine);

            }
            if (pro.MatchId < 1)
            {
                IsValidSchedule = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
          
            if (pro.VenueId.ToString().Equals(string.Empty))
            {
                IsValidSchedule = false;
                sb.Append("VenueId cannot be blank " + Environment.NewLine);

            }
            if (pro.VenueId < 1)
            {
                IsValidSchedule = false;
                sb.Append(Environment.NewLine + "VenueId should not be negative");
            }
            //validation for date,starting time and ending time
            return IsValidSchedule;
        }
        //AddScheduleBAL
        public int AddScheduleBAL(SchedulEntity pobj)
        {
            try
            {
                int pid = 0;
                ScheduleDal pd = new ScheduleDal();
                if (ValidateSchedule(pobj))
                {
                    pid = pd.AddScheduleDAL(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //DisplayScheduleBal
        public DataTable DisplayScheduleBal()
        {
            try
            {
                ScheduleDal sd = new ScheduleDal();
                DataTable dtProduct = sd.DisplayScheduleDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Student Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //UpdateScheduleBal
        public bool UpdateScheduleBal(SchedulEntity upmatch)
        {
            bool Scheduleupdated = false;
            try
            {
                if (ValidateSchedule(upmatch))
                {
                    ScheduleDal matchdal = new ScheduleDal();//give Dal class 
                    Scheduleupdated = matchdal.UpdateScheduleDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Scheduleupdated;

        }
        //DeleteScheduleBAL
        public static bool DeleteScheduleBAL(string ScheduleId)
        {
            bool ScheduleDeleted = false;
            try
            {
                ScheduleDal deleteIPLdal = new ScheduleDal();
                ScheduleDeleted = deleteIPLdal.DeleteScheduleDAL(ScheduleId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ScheduleDeleted;
        }
    }
}
