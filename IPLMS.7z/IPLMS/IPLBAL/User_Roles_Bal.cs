﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using IPL_DAL;
using System.Data;
using System.Data.SqlClient;

namespace IPLBAL
{
    public class User_Roles_Bal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateUserRoles(UserRoles pro)
        {


            bool IsValidUserRole = true;

           
            if (pro.UserId.ToString().Equals(string.Empty))
            {
                IsValidUserRole = false;
                sb.Append("UserId cannot be blank " + Environment.NewLine);

            }
            if (pro.UserId < 1)
            {
                IsValidUserRole = false;
                sb.Append(Environment.NewLine + "UserId should not be negative");
            }

            if (pro.RoleId.ToString().Equals(string.Empty))
            {
                IsValidUserRole = false;
                sb.Append("RoleId cannot be blank " + Environment.NewLine);

            }
             if (pro.RoleId < 1)
            {
                IsValidUserRole = false;
                sb.Append(Environment.NewLine + "RoleId should not be negative");
            }



            return IsValidUserRole;
        }
        public int AddUserRolesBAL(UserRoles pobj)
        {
            try
            {
                int pid = 0;
                UserRolesDal pd = new UserRolesDal();
                if (ValidateUserRoles(pobj))
                {
                    pid = pd.AddUserRolesDAL(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //UserRolesViewBal
        public DataTable UserRolesViewBal()
        {
            try
            {
                UserRolesDal sd = new UserRolesDal();
                DataTable dtProduct = sd.UserRolesDisplayDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No User Roles Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //update
        public bool UpdateUserRolesBal(UserRoles us)
        {
            bool Matchupdated = false;
            try
            {
               

                if (ValidateUserRoles(us))
                {
                    UserRolesDal matchdal = new UserRolesDal();
                    Matchupdated = matchdal.UpdateUserRolesDal(us);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
    }
}
