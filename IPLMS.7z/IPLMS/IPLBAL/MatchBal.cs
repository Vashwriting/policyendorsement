﻿using IPL_DAL;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPLEntities;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace IPLBAL
{
    public class MatchBal
    {
        StringBuilder sb = new StringBuilder();
        private  bool ValidateMatch(MatchEntities pro)
        {
            bool IsValidProduct = true;
           

            if (pro.MatchId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("MatchId cannot be blank " + Environment.NewLine);

            }
            if (pro.TeamOneId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("TeamOneId cannot be blank " + Environment.NewLine);

            }
            if (pro.TeamTwoId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("TeamTwoId cannot be blank " + Environment.NewLine);

            }
            if (pro.VenueId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("VenueId cannot be blank " + Environment.NewLine);

            }
            if (pro.ScheduleId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("ScheduleId cannot be blank " + Environment.NewLine);

            }
            if (pro.PhotoGroupId.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("PhotoGroupId cannot be blank " + Environment.NewLine);

            }
            if (pro.MatchId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            if (pro.TeamOneId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            if (pro.TeamTwoId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            if (pro.VenueId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            if (pro.ScheduleId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            if (pro.PhotoGroupId < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            return IsValidProduct;
        }

        //AddMatchBAL
        public  int AddMatchBAL(MatchEntities pobj)
        {
            try
            {
                int pid = 0;
                MatchDal pd = new MatchDal();
                if (ValidateMatch(pobj))
                {
                    pid = pd.AddMatchDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        public DataTable DisplayMatchBal()
        {
            try
            {
                MatchDal sd = new MatchDal();
                DataTable dtProduct = sd.DisplayMatchDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Student Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //update
        public  bool UpdateMatchBal(MatchEntities upmatch)
        {
            bool Matchupdated = false;
            try
            {
                if (ValidateMatch(upmatch)) 
                    {
                    MatchDal matchdal = new MatchDal();
                    Matchupdated = matchdal.UpdateMatch(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
        //DeleteMatchBal
        public static bool DeleteMatchBal(string MatchId)
        {
            bool VenueDeleted = false;
            try
            {
                MatchDal deletehoteldal = new MatchDal();
                VenueDeleted = deletehoteldal.DeleteVenueDAL(MatchId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return VenueDeleted;
        }
    }
}
