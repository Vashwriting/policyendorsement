﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class Team
    {
       
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public string HomeGround { get; set; }
        public string Owner { get; set; }
        public byte[] LogoImage { get; set; }
    }
}
