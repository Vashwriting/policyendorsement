﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class PlayerPhoto
    {
        public int PlayerId { get; set; }
        public byte[] Photo { get; set; }
    }
}
