create schema IPL;
----------------------------------------------------------------------
--for login
 CREATE TABLE [IPL].[RegisterDetails](
	[UserName] [varchar](25) NOT NULL,
	[Password] [varchar](25) NULL,
 );  
 select * from [IPL].[RegisterDetails]
 ----------------------------------------------------
CREATE TABLE [IPL].[Users](
	[UserId] [int] NOT NULL,
	[UserName] [varchar](25) NOT NULL,
	[Password] [varchar](25) NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY (UserId)
 );  
 
 select * from [IPL].[Users]
 
------------------------------------------------------
CREATE TABLE [IPL].[Roles](
	[RoleId] [int] NOT NULL,
	[RoleName] [varchar](25) NOT NULL,
	
 CONSTRAINT [PK_Roles] PRIMARY KEY (RoleId)
 );  
 select * from [IPL].[Roles]
 -----------------------------------------------------
 CREATE TABLE [IPL].[UserRoles](
	[UserId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
	
 CONSTRAINT [PK_UserRoles] PRIMARY KEY (UserId),
 FOREIGN KEY(RoleId) REFERENCES [IPL].[Roles](RoleId),
 FOREIGN KEY(UserId) REFERENCES [IPL].[Users](UserId)

 );  
 select * from [IPL].[UserRoles]
 
----------------------------------------------------------------  
CREATE TABLE [IPL].[Team](
	[TeamId] [int] NOT NULL,
	[TeamName] [varchar](25) NOT NULL,
	[HomeGround] [varchar](25) NULL,
	[Owner] [varchar](50) NULL,
	[LogoImage] [Image] NULL,
 CONSTRAINT [PK_Team] PRIMARY KEY (TeamId)
 );  
  select * from [IPL].[Team]
  
------------------------------------------------------------ 
CREATE TABLE [IPL].[Player](
	[PlayerId] [int] NOT NULL,
	[TeamId] [int] NOT NULL,
	[PlayerName] [varchar](25) NOT NULL,
	[PlayerAge] int NULL,
	[PlayerSpeciality] [varchar](50) NULL,
	
 CONSTRAINT [PK_Player] PRIMARY KEY (PlayerId),
 FOREIGN KEY(TeamId) REFERENCES [IPL].[Team](TeamId)

 );
  select * from [IPL].[Player]
 
-------------------------------------------------------------
CREATE TABLE [IPL].[PlayerPhoto](
	[PlayerId] [int] NOT NULL,
	[PlayerPhoto] [Image] NULL,
	
 FOREIGN KEY(PlayerId) REFERENCES [IPL].[Player](PlayerId)

 );
 select * from [IPL].[PlayerPhoto]
 -------------------------------------------------------------
 CREATE TABLE [IPL].[Speciality](
	[SpecialityId] [int] NOT NULL,
	[SpecialityDescription] [varchar](50) NULL,
	
 CONSTRAINT [PK_Speciality] PRIMARY KEY (SpecialityId),

 );
 select * from [IPL].[Speciality]
 --------------------------------------------------------------------
 CREATE TABLE [IPL].[Match_1](
	[MatchId] [int] NOT NULL,
	[TeamOneId] [int] NOT NULL,
	[TeamTwoId] [int] NOT NULL,
	[VenueId] [int] NOT NULL,
	[ScheduleId] [int] NOT NULL,
	[PhotoGroupId] [int] NOT NULL,

 CONSTRAINT [PK_Match_1] PRIMARY KEY (MatchId),
 FOREIGN KEY(TeamOneId) REFERENCES  [IPL].[Team](TeamId),
 FOREIGN KEY(TeamTwoId) REFERENCES [IPL].[Team](TeamId),
 FOREIGN KEY(VenueId) REFERENCES [IPL].[Venue](VenueId),
 
 );
 select * from [IPL].[Match_1]
 
 --------------------------------------------
 CREATE TABLE [IPL].[MatchPhoto](
	[MatchPhotoId] [int] NOT NULL,
	[MatchId] [int] NULL,
	[Photo] [Image] NULL,

 CONSTRAINT [PK_MatchPhoto] PRIMARY KEY (MatchPhotoId),	
 FOREIGN KEY(MatchId) REFERENCES [IPL].[Match](MatchId)

 );
 select * from [IPL].[MatchPhoto]

 ---------------------------------------------
 CREATE TABLE [IPL].[Venue](
	[VenueId] [int] NOT NULL,
	[Location] [varchar](25) NOT NULL,
    [Description] [varchar](50) NULL,
	
 CONSTRAINT [PK_Venue] PRIMARY KEY (VenueId)
 );  
 select * from [IPL].[Venue]
 
 ---------------------------------------------
  CREATE TABLE [IPL].[Schedule](
	[ScheduleId] [int] NOT NULL,
	[MatchId] [int] NOT NULL,
	[VenueId] [int] NOT NULL,
	[Date] [DateTime] NOT NULL,
	[StartTime] [DateTime] NOT NULL,
	[EndTime] [DateTime] NOT NULL,
	
 CONSTRAINT [PK_Schedule] PRIMARY KEY (ScheduleId),
 FOREIGN KEY(MatchId) REFERENCES [IPL].[Match_1](MatchId),
 FOREIGN KEY(VenueId) REFERENCES [IPL].[Venue](VenueId),

 ); 
 select * from [IPL].[Schedule]
 
 ----------------------------------------------
 CREATE TABLE [IPL].[Ticket](
	[TicketId] [int] NOT NULL PRIMARY KEY,
	[MatchId] [int] NOT NULL,
	[CategoryId] [int] NOt NULL,
	[Price] [Money] not NULL,
 FOREIGN KEY(MatchId) REFERENCES [IPL].[Match_1](MatchId),
 FOREIGN KEY(CategoryId) REFERENCES [IPL].[TicketCategory](TC_Id),

 ); 
 select * from [IPL].[Ticket]
 
 
 -------------------------------------
 CREATE TABLE [IPL].[TicketCategory](
	[TC_Id] [int] NOT NULL PRIMARY KEY,
	[TC_Name] [varchar](25) NOT NULL,
	[TC_Description] [varchar](105) NULL,

 );  
 select * from [IPL].[TicketCategory]
 
 ------------------------------------
 CREATE TABLE [IPL].[News](
	[NewsId] [int] NOT NULL PRIMARY KEY,
	[NewsDate] [DateTime] NOT NULL,
	[MatchId] [int] NULL,
	[Description] [varchar](100) NULL,
	[MatchPhotoId] [int] NULL,
 FOREIGN KEY(MatchId) REFERENCES [IPL].[Match_1](MatchId),
 FOREIGN KEY(MatchPhotoId) REFERENCES [IPL].[MatchPhoto](MatchPhotoId),

 );  
 select * from [IPL].[News]
 -------------------------
 CREATE TABLE [IPL].[Statistics](
	[TeamId] [int] NOT NULL,
	[Status] [varchar](25) NOT NULL,	
	[NetRate] [varchar](50) NULL,
	[NetRunRate] [varchar](50) NULL,
	[ForAgainst] [varchar](50) NULL,
	[Points] [int] NOT NULL,
	[From] [int] NOT NULL,

 FOREIGN KEY(TeamId) REFERENCES [IPL].[Team](TeamId),

 );  
 select * from [IPL].[Statistics]