﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

//club 
namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for MatchWindow.xaml
    /// </summary>
    public partial class MatchWindow : Window
    {
        public MatchWindow()
        {
            InitializeComponent();
        }
        string strName1, imageName1;
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }
        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            ViewMatch ha = new ViewMatch(); //create your new form.
            ha.Show(); //show the new form.
            this.Close();
        }
        //update
        private static void UpdateMatch(MatchEntities editemp)
        {

            try
            {
                MatchBal pb = new MatchBal();
                bool employeeedited = pb.UpdateMatchBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("employee edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;

            MatchEntities type = new MatchEntities();
            MatchPhoto type2 = new MatchPhoto();
            type.MatchId = int.Parse(textBox_MatchId1.Text);
            type.TeamOneId = int.Parse(textBox_TeamOneId.Text);
            type.TeamTwoId = int.Parse(textBox_TeamTwoId.Text);
            type.VenueId = int.Parse(txt_VenueId.Text);
            type.ScheduleId = int.Parse(txt_ScheduleId.Text);
            type.PhotoGroupId = int.Parse(txt_PhotoGroupId.Text);
            //here
            type2.Photo = imgByteArr;
            UpdateMatch(type);
        }

       
        //add
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;

            if (imageName1 != "")
            {
                //Initialize a file stream to read the image file
                FileStream fs = new FileStream(imageName1, FileMode.Open, FileAccess.Read);

                //Initialize a byte array with size of stream
                imgByteArr = new byte[fs.Length];

                //Read data from the file stream and put into the byte array
                fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                //Close a file stream
                fs.Close();
                try
                {
                    MatchEntities p = new MatchEntities
                    {
                        MatchId = int.Parse(textBox_MatchId1.Text),
                        TeamOneId = int.Parse(textBox_TeamOneId.Text),
                        TeamTwoId = int.Parse(textBox_TeamTwoId.Text),
                        VenueId = int.Parse(txt_VenueId.Text),
                        ScheduleId = int.Parse(txt_ScheduleId.Text),
                        PhotoGroupId = int.Parse(txt_ScheduleId.Text)
                    };

                    MatchBal pb = new MatchBal();
                    int pid = pb.AddMatchBAL(p);
                    MessageBox.Show(string.Format("Match Details Added Successfully"),
                        "IPL Management System");
                }
                catch (IPLException ex)
                {
                    MessageBox.Show(ex.Message, "IPL Management System");
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(ex.Message, "IPL Management System");
                }
            }

        }

        private void Matchinfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileDialog fldlg = new OpenFileDialog();
                fldlg.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();
                fldlg.Filter = "Images (*.jpg,*.png)|*.jpg;*.png|All Files(*.*)|*.*";
                fldlg.ShowDialog();
                {
                    strName1 = fldlg.SafeFileName;
                    imageName1 = fldlg.FileName;
                    ImageSourceConverter isc = new ImageSourceConverter();
                    MatchPhoto.SetValue(Image.SourceProperty, isc.ConvertFromString(imageName1));
                }
                fldlg = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }


    }
}
