﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLBAL;
using Microsoft.Win32;
using System.IO;
using System.Data.SqlClient;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for PlayerPhotoWindow.xaml
    /// </summary>
    public partial class PlayerPhotoWindow : Window
    {
        public PlayerPhotoWindow()
        {
            InitializeComponent();
        }

        string strName1, imageName1;



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileDialog fldlg = new OpenFileDialog();
                fldlg.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();
                fldlg.Filter = "Images (*.jpg,*.png)|*.jpg;*.png|All Files(*.*)|*.*";
                fldlg.ShowDialog();
                {
                    strName1 = fldlg.SafeFileName;
                    imageName1 = fldlg.FileName;
                    ImageSourceConverter isc = new ImageSourceConverter();
                    PlayerPhoto.SetValue(Image.SourceProperty, isc.ConvertFromString(imageName1));
                }
                fldlg = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Playerphotoinfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
        //update
        private static void UpdateMatch(PlayerPhoto editemp)
        {

            try
            {
                PlayerPhotoBal pb = new PlayerPhotoBal();
                bool employeeedited = pb.UpdatePlayerPhotoBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("PlayerPhoto edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;

            if (imageName1 != "")
            {
                //Initialize a file stream to read the image file
                FileStream fs = new FileStream(imageName1, FileMode.Open, FileAccess.Read);

                //Initialize a byte array with size of stream
                imgByteArr = new byte[fs.Length];

                //Read data from the file stream and put into the byte array
                fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                //Close a file stream
                fs.Close();
                PlayerPhoto type = new PlayerPhoto();
                type.PlayerId = int.Parse(txt_Teanid.Text);
                type.Photo = imgByteArr;


                UpdateMatch(type);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int PlayerPhoto = Int32.Parse(txt_Teanid.Text);
            try
            {
                bool PlayerPhotoVenueDeleted = PlayerPhotoBal.DeletePlayerPhotoBal(PlayerPhoto.ToString());

                if (PlayerPhotoVenueDeleted)
                    MessageBox.Show("PlayerPhoto Deleted successfully");
                else
                    MessageBox.Show("Venue not Deleted");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            byte[] imgByteArr = null;

            if (imageName1 != "")
            {
                try
                {
                    //Initialize a file stream to read the image file
                    FileStream fs = new FileStream(imageName1, FileMode.Open, FileAccess.Read);

                    //Initialize a byte array with size of stream
                    imgByteArr = new byte[fs.Length];

                    //Read data from the file stream and put into the byte array
                    fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                    //Close a file stream
                    fs.Close();

                    try
                    {
                        PlayerPhoto p = new PlayerPhoto
                        {
                            PlayerId = int.Parse(txt_Teanid.Text),
                            Photo = imgByteArr
                        };

                        PlayerPhotoBal pb = new PlayerPhotoBal();
                        int pid = pb.AddPlayerPhotoBAL(p);
                        MessageBox.Show(string.Format("New Player Photo Added"),
                            "IPL Management System");
                    }
                    catch (IPLException ex)
                    {
                        MessageBox.Show(ex.Message, "IPL Management System");
                    }
                    catch (SystemException ex)
                    {
                        MessageBox.Show(ex.Message, "IPL Management System");
                    }
                }
                catch(Exception)
                {
                    MessageBox.Show("Photo Is Required");
                }
            }
        }
    }
}
