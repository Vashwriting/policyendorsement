﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for VenueWindow.xaml
    /// </summary>
    public partial class VenueWindow : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public VenueWindow()
        {
            InitializeComponent();
        }

        private void Venue_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Venue p = new Venue
                {
                    VenueId = int.Parse(textBoxVenueId.Text),
                    Location = txtVenueLocation_.Text,
                    Description = textBoxuserid.Text
                };

                VenueBal pb = new VenueBal();
                int pid = pb.AddVenueBAL(p);
                MessageBox.Show(string.Format("Venue Details Added Successfully"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        //view
        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            View_Venue main1 = new View_Venue(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
        //update
        private static void UpdateVenue(Venue editemp)
        {

            try
            {
                VenueBal pb = new VenueBal();
                bool employeeedited = pb.UpdateVenueBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("Venue Updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            Venue type = new Venue();
            type.VenueId = int.Parse(textBoxVenueId.Text);
            type.Location = txtVenueLocation_.Text;
            type.Description = textBoxuserid.Text;
            UpdateVenue(type);

        }
        //delete
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int VenueId =Int32.Parse(textBoxVenueId.Text);
            try
            {
                bool VenueDeleted = VenueBal.DeleteVenuePL(VenueId.ToString());

                if (VenueDeleted)
                    MessageBox.Show("Venue Deleted successfully");
                else
                    MessageBox.Show("Venue not Deleted");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }
    }
}
