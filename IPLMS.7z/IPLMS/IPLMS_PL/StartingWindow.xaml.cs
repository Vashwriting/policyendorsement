﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for StartingWindow.xaml
    /// </summary>
    public partial class StartingWindow : Window
    {
        public StartingWindow()
        {
            InitializeComponent();
        }

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {
            Register main1 = new Register(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main1 = new MainWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
