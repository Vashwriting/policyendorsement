﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLEntities;
using IPLExceptions;
using IPLBAL;
using System.Data.SqlClient;
using System.Data;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for Team_Window.xaml
    /// </summary>
    public partial class Team_Window : Window
    {
       

        public Team_Window()
        {
            InitializeComponent();
        }
        string strName, imageName;
        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           

            try
            {
                FileDialog fldlg = new OpenFileDialog();
                fldlg.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();
                fldlg.Filter = "Images (*.jpg,*.png)|*.jpg;*.png|All Files(*.*)|*.*";
                fldlg.ShowDialog();
                {
                    strName = fldlg.SafeFileName;
                    imageName = fldlg.FileName;
                    ImageSourceConverter isc = new ImageSourceConverter();
                    LgoImage.SetValue(Image.SourceProperty, isc.ConvertFromString(imageName));
                }
                fldlg = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void Teaminfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
        //view
        private void btnView_Click(object sender, RoutedEventArgs e)
        {
           
            View_Team main1 = new View_Team(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
        //update
        private static void UpdateTeam(Team editemp)
        {

            try
            {
                TeamBal pb = new TeamBal();
                bool employeeedited = pb.UpdateTeamBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("Team Updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;
            {
                //Initialize a file stream to read the image file
                FileStream fs = new FileStream(imageName, FileMode.Open, FileAccess.Read);

                //Initialize a byte array with size of stream
                imgByteArr = new byte[fs.Length];

                //Read data from the file stream and put into the byte array
                fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                //Close a file stream
                fs.Close();
                Team type = new Team();

                type.HomeGround = textBox_HomeGround.Text;
                type.LogoImage = imgByteArr;
                type.TeamId = int.Parse(textBox_TeamId.Text);
                type.TeamName = textBox_LastName.Text;
                type.Owner = txt_Owner1.Text;

                UpdateTeam(type);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int TeamId = Int32.Parse(textBox_TeamId.Text);
            try
            {
                bool TeamDeleted = TeamBal.DeleteVenueBal(TeamId.ToString());

                if (TeamDeleted)
                    MessageBox.Show("Team Deleted successfully");
                else
                    MessageBox.Show("Team not Deleted");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            byte[] imgByteArr = null;

            if (imageName != "")
            {
                //Initialize a file stream to read the image file
                FileStream fs = new FileStream(imageName, FileMode.Open, FileAccess.Read);

                //Initialize a byte array with size of stream
                imgByteArr = new byte[fs.Length];

                //Read data from the file stream and put into the byte array
                fs.Read(imgByteArr, 0, Convert.ToInt32(fs.Length));

                //Close a file stream
                fs.Close();

                try
                {
                    Team team = new Team
                    {
                        HomeGround = textBox_HomeGround.Text,
                        LogoImage = imgByteArr,
                        TeamId = int.Parse(textBox_TeamId.Text),
                        TeamName = textBox_LastName.Text,
                        Owner = txt_Owner1.Text
                    };

                    TeamBal pb = new TeamBal();
                    int pid = pb.AddTeamBAL(team);
                    MessageBox.Show(string.Format("New Team Added"),
                        "IPL Management System");
                }
                catch (IPLException ex)
                {
                    MessageBox.Show(ex.Message, "IPL Management System");
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(ex.Message, "IPL Management System");
                }
            }
        }
    }
}
