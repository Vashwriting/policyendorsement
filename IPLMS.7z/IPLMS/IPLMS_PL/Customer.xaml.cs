﻿using IPL_PL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPLMS_PL
{
    /// <summary>
    /// Interaction logic for Customer.xaml
    /// </summary>
    public partial class Customer : Window
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {

            View_Team main1 = new View_Team(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            View_Player main1 = new View_Player(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            View_Ticket main1 = new View_Ticket(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click_2(object sender, RoutedEventArgs e)
        {
            TicketBooking main1 = new TicketBooking(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click_3(object sender, RoutedEventArgs e)
        {
            View_Schedule main1 = new View_Schedule(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click_4(object sender, RoutedEventArgs e)
        {
            View_Venue main1 = new View_Venue(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Hyperlink_Click_5(object sender, RoutedEventArgs e)
        {
            StartingWindow main1 = new StartingWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
