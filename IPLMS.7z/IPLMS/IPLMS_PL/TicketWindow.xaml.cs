﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for TicketWindow.xaml
    /// </summary>
    public partial class TicketWindow : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public TicketWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Ticket p = new Ticket
                {
                    TicketId= int.Parse(txtTicketId.Text),
                    CategoryId=int.Parse(textCategoryId.Text),
                    MatchId = int.Parse(textBox_MatchId1.Text),
                    Price=float.Parse(txt_Price.Text)
                };



                TicketBal pb = new TicketBal();
                int pid = pb.AddTicketBAL(p);
                MessageBox.Show(string.Format("New Ticket Added"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            View_Ticket main1 = new View_Ticket(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private static void UpdateTicket(Ticket editemp)
        {

            try
            {
                TicketBal pb = new TicketBal();
                bool Ticketedited = pb.UpdateTicketBal(editemp);
                if (Ticketedited)
                {
                    MessageBox.Show("Ticket Updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Ticket type = new Ticket();
            type.TicketId = int.Parse(txtTicketId.Text);
            type.MatchId = int.Parse(textBox_MatchId1.Text);
            type.CategoryId = int.Parse(textCategoryId.Text);
            type.Price = float.Parse(txt_Price.Text);
           
            UpdateTicket(type);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int TicketId = Int32.Parse(txtTicketId.Text);
            try
            {
                bool TicketDeleted = TicketBal.DeleteTicketBal(TicketId.ToString());

                if (TicketDeleted)
                    MessageBox.Show("Ticket Deleted successfully");
                else
                    MessageBox.Show("Ticket not Deleted");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }

        private void Matchinfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow n = new LinkWindow(); //create your new form.
            n.Show(); //show the new form.
            this.Close();
        }
    }
}
